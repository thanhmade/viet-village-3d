@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Can Node.js de cai bo VFX. Hay cai Node.js LTS, mo lai file nay.
  echo Khong tep game nao bi thay doi.
  pause
  exit /b 1
)
node "%~dp0INSTALL-WEAPONS-VFX.cjs" %*
set "VFX_EXIT_CODE=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %VFX_EXIT_CODE%
