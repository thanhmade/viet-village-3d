@echo off
start "" "%~dp0SOURCE-CODE\weapons-vfx-demo.html"
