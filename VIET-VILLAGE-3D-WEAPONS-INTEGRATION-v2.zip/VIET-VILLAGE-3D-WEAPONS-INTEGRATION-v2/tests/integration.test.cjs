/* Chạy từ thư mục gói: node --test tests/integration.test.cjs
 * Geometry/transform thật của Three.js; DOM và render được mô phỏng.
 * Kiểm tra thêm khai báo lexical thực tế của bản nền:
 * VVW_BASELINE_DIR=<thư mục game> node --test tests/integration.test.cjs
 * Không cần npm hoặc WebGL. Không thay thế kiểm tra hình ảnh trên trình duyệt.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { test } = require('node:test');
const T = require('../TEST-ASSETS/three.min.js');
const runtime = path.join(__dirname, '../PAYLOAD/SOURCE-CODE/js/vfx');
const weapons = ['staff', 'sword', 'spear', 'bow', 'axe'];
const baselineDir = process.env.VVW_BASELINE_DIR;

class Element {
  constructor(tagName = 'div', id = '') {
    this.tagName = tagName.toUpperCase(); this.id = id; this.style = {}; this.value = '';
    this.children = []; this.parentNode = null; this.listeners = new Map(); this.listenerCapture = new Map(); this.classes = new Set();
    this.classList = {
      add: name => this.classes.add(name), remove: name => this.classes.delete(name),
      contains: name => this.classes.has(name),
      toggle: (name, force) => {
        const value = force === undefined ? !this.classes.has(name) : force;
        if (value) this.classes.add(name); else this.classes.delete(name); return value;
      }
    };
  }
  addEventListener(type, fn, options) { if (!this.listeners.has(type)) this.listeners.set(type, new Set()); this.listeners.get(type).add(fn); this.listenerCapture.set(fn, options === true || !!options?.capture); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); this.listenerCapture.delete(fn); }
  setAttribute(name, value) { this[name] = String(value); }
  appendChild(child) { child.remove(); child.parentNode = this; this.children.push(child); return child; }
  append(...children) { children.forEach(child => this.appendChild(child)); }
  replaceChildren(...children) { this.children.forEach(child => child.parentNode = null); this.children = []; this.append(...children); }
  remove() { if (!this.parentNode) return; const parent = this.parentNode; parent.children.splice(parent.children.indexOf(this), 1); this.parentNode = null; }
  dispatchEvent(event) {
    event.target ||= this; const listeners = [...(this.listeners.get(event.type) || [])];
    for (const fn of listeners.filter(fn => this.listenerCapture.get(fn))) fn(event);
    this['on' + event.type]?.(event); // Baseline toolbar onclick existed before the integration listener.
    for (const fn of listeners.filter(fn => !this.listenerCapture.get(fn))) fn(event); return true;
  }
  click() { this.dispatchEvent({ type: 'click' }); }
}
function findId(element, id) {
  if (element.id === id) return element;
  for (const child of element.children) { const found = findId(child, id); if (found) return found; }
  return null;
}
function near(actual, expected, message, tolerance = 1e-6) { assert.ok(Math.abs(actual - expected) < tolerance, `${message}: ${actual} ≈ ${expected}`); }
function vectorNear(a, b, message) { for (const axis of ['x', 'y', 'z']) near(a[axis], b[axis], `${message}.${axis}`); }

function fixture({ deferred = false } = {}) {
  const documentBody = new Element('body');
  const ids = {};
  for (const id of ['home', 'hud', 'quality', 'overviewBtn', 'cameraBtn', 'gateBtn', 'houseBtn', 'enterHouseBtn', 'quiz', 'levels', 'complete', 'referenceGallery', 'knob']) {
    const tag = id === 'quality' ? 'select' : /Btn$/.test(id) ? 'button' : 'div';
    ids[id] = new Element(tag, id); documentBody.appendChild(ids[id]);
  }
  ids.hud.style.display = 'none'; ids.quality.value = 'auto';
  for (const id of ['quiz', 'levels', 'complete', 'referenceGallery']) ids[id].classList.add('hidden');
  const tools = new Element('div'); ids.hud.appendChild(tools);
  const events = [], listeners = new Map(); let rafCalls = 0, renderCalls = 0;
  const context = {
    THREE: T, console,
    document: { body: documentBody, getElementById: id => findId(documentBody, id), createElement: tag => new Element(tag),
      querySelector: selector => selector === '#hud .tools' ? tools : null },
    CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } },
    addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, new Set()); listeners.get(type).add(fn); },
    removeEventListener(type, fn) { listeners.get(type)?.delete(fn); },
    dispatchEvent(event) { events.push(event); for (const fn of [...(listeners.get(event.type) || [])]) fn(event); return true; },
    requestAnimationFrame() { rafCalls++; return rafCalls; },
    setTimeout, clearTimeout,
    localStorage: { getItem: () => null },
    innerWidth: 1280, innerHeight: 720,
    renderScene() { renderCalls++; }
  };
  context.window = context; vm.createContext(context);
  const evaluate = source => vm.runInContext(source, context);
  if (baselineDir) {
    const source = path.join(baselineDir, 'SOURCE-CODE/js/state-and-questions.js');
    assert.ok(fs.existsSync(source), 'VVW_BASELINE_DIR phải chứa SOURCE-CODE/js/state-and-questions.js');
    evaluate(fs.readFileSync(source, 'utf8'));
  } else {
    // Cùng dạng lexical globals với SOURCE-CODE/js/state-and-questions.js.
    evaluate(`const $ = id => document.getElementById(id);
      let renderer,scene,camera,player,body,leftLeg,rightLeg,leftArm,rightArm;
      let world=new THREE.Group(),active=false,yaw=0,pitch=.5,keys={},joystick={},target=null,drag=null;`);
  }
  evaluate(`
    scene=new THREE.Scene(); renderer={render:renderScene,tag:'existing-game-renderer'};
    camera=new THREE.PerspectiveCamera(48,16/9,.1,180);
    scene.add(world); player=new THREE.Group();scene.add(player);player.position.set(0,.3,21);player.visible=false;
    body=new THREE.Group();player.add(body);body.position.y=.015;
    leftLeg=new THREE.Group();rightLeg=new THREE.Group();leftArm=new THREE.Group();rightArm=new THREE.Group();
    for(const limb of [leftLeg,rightLeg,leftArm,rightArm])body.add(limb);
    rightArm.position.set(.43,1.47,0);leftArm.position.set(-.43,1.47,0);
    let insideHouse=false,sceneryRadius=60,sceneryFocus=new THREE.Vector3(0,1,0),gateView=2,houseView=3;
    let housePreview=new THREE.Group();housePreview.visible=true;scene.add(housePreview);world.visible=false;
    function bridgeHeight(x,z){return Math.abs(z-18)<.95&&x>=9.2&&x<=20.8?.45+1.25*Math.sin(Math.PI*(x-9.2)/11.6):.3;}
    function canWalk(x,z){return Math.abs(x)<24.1&&Math.abs(z)<26.1&&!(x>2&&x<5&&z>18&&z<23);}
    function overlays(){return ['home','quiz','levels','complete','referenceGallery'].some(id=>!$(id).classList.contains('hidden'));}
    function clearMotion(){keys={};joystick={};target=null;drag=null;}
    function tickFixture(dt){window.VietVillageWeapons?.update(dt);renderer.render(scene,camera);}
  `);
  ids.cameraBtn.onclick = () => evaluate('yaw=.55;pitch=.67;sceneryRadius=60;sceneryFocus.set(0,1,0);world.visible=true;housePreview.visible=false;gateView=-1;houseView=-1');
  ids.houseBtn.onclick = () => evaluate('world.visible=false;housePreview.visible=true;gateView=-1;houseView=0;sceneryFocus.set(11,2,0);sceneryRadius=12;yaw=0;pitch=.22');
  if (deferred) evaluate('window.__lateBindings={scene,player,body,rightArm};scene=undefined;player=undefined;body=undefined;rightArm=undefined;');
  const files = ['weapon-vfx-core.js', ...weapons.flatMap(id => [`${id}-skill-config.js`, `${id}-skill-vfx.js`]), 'weapon-preview-models.js', 'weapon-game-integration.js'];
  for (const file of files) vm.runInContext(fs.readFileSync(path.join(runtime, file), 'utf8'), context, { filename: file });
  const api = context.VietVillageWeapons;
  const state = () => evaluate('({scene,renderer,camera,player,body,leftLeg,rightLeg,leftArm,rightArm,world,housePreview,yaw,pitch,sceneryRadius,sceneryFocus,insideHouse,keys,active,gateView,houseView})');
  const key = (code, options = {}) => {
    let prevented = false;
    context.dispatchEvent({ type: 'keydown', code, repeat: false, target: documentBody, preventDefault() { prevented = true; }, ...options });
    return prevented;
  };
  const tick = dt => evaluate(`tickFixture(${dt})`);
  return { context, documentBody, ids, events, listeners, evaluate, state, key, tick, api, counts: () => ({ rafCalls, renderCalls }) };
}

test('tự nhận globals lexical thật; dùng scene/renderer/vòng lặp có sẵn', () => {
  const f = fixture(), before = f.state();
  assert.equal(f.context.scene, undefined, 'scene lexical không phải window.scene');
  assert.equal(f.api.init(), true); assert.equal(f.api.manager.scene, before.scene);
  assert.equal(f.api.caster.parent, before.body);
  assert.equal(f.api.weaponTip.parent.parent.parent.parent, before.rightArm);
  assert.equal(f.state().renderer, before.renderer); assert.equal(f.state().camera, before.camera);
  f.ids.home.classList.add('hidden');
  const time = f.api.manager.time; f.tick(.04); near(f.api.manager.time, time + .04, 'tick cập nhật manager');
  assert.equal(f.counts().renderCalls, 1); assert.equal(f.counts().rafCalls, 0, 'Adapter không tạo RAF');
  assert.ok(f.documentBody.children.some(node => node.id === 'vvw-panel'));
  f.api.dispose();
});

test('proxy -Z khớp hướng +Z nhân vật khi body và ancestor quay', () => {
  const f = fixture(); f.api.init(); const state = f.state();
  for (const rotation of [-2.5, -.7, 0, .9, Math.PI]) {
    state.player.rotation.y = .23; state.body.rotation.y = rotation;
    const facing = new T.Vector3(0, 0, 1).applyQuaternion(state.body.getWorldQuaternion(new T.Quaternion()));
    const proxy = new T.Vector3(0, 0, -1).applyQuaternion(f.api.caster.getWorldQuaternion(new T.Quaternion()));
    vectorNear(proxy, facing, 'proxy cùng hướng mặt nhân vật');
  }
  f.api.dispose();
});

test('adapter nạp trước app chờ globals được tạo rồi tự attach ở tick có sẵn', () => {
  const f = fixture({ deferred: true });
  assert.equal(f.api.init(), false); assert.equal(f.api.manager, null);
  assert.equal(f.api.cast(1).reason, 'game-not-ready');
  f.evaluate('({scene,player,body,rightArm}=window.__lateBindings);delete window.__lateBindings;');
  f.ids.home.classList.add('hidden'); f.tick(.04);
  assert.ok(f.api.manager); assert.equal(f.api.manager.scene, f.state().scene);
  assert.equal(f.counts().renderCalls, 1); assert.equal(f.counts().rafCalls, 0);
  assert.equal(f.api.enterPractice(), true); assert.equal(f.api.cast(1).ok, true); f.api.dispose();
});

test('5 trang bị thật và 15 chiêu chạy trong cùng cảnh, phát sự kiện đầy đủ', () => {
  const f = fixture(); assert.equal(f.api.enterPractice(), true);
  const configs = f.context.WeaponVFXCore.getWeaponConfigs(); let count = 0;
  for (const config of configs) {
    assert.equal(f.api.equip(config.weaponId).ok, true); assert.equal(f.state().player.userData.weaponId, config.weaponId);
    assert.equal(f.api.weaponTip.name, config.weaponId + '-tip');
    for (const skill of config.skills) {
      const result = f.api.cast(skill.slot); assert.equal(result.ok, true, skill.id); count++;
      assert.equal(result.skillId, skill.id);
      for (let elapsed = 0; elapsed < skill.duration + .8; elapsed += .04) f.tick(.04);
      assert.ok(f.events.some(event => event.type === 'viet-village:skill-event' && event.detail.skillId === skill.id && event.detail.type === 'cast'));
      assert.ok(f.events.some(event => event.type === 'viet-village:skill-event' && event.detail.skillId === skill.id && event.detail.type === 'complete'));
    }
  }
  assert.equal(count, 15); assert.equal(new Set(f.events.filter(e => e.type === 'viet-village:weapon-equipped').map(e => e.detail.weaponId)).size, 5);
  assert.equal(f.counts().rafCalls, 0); f.api.dispose();
});

test('luyện chiêu di chuyển có mặt đất/camera; thoát trả vị trí, hướng, limb và UI', () => {
  const f = fixture(), before = f.state();
  before.player.position.set(10, .3, 18); before.body.rotation.set(.1, -.8, .2); before.leftLeg.rotation.x = .21;
  const saved = { position: before.player.position.clone(), rotation: before.body.rotation.clone(), bodyPosition: before.body.position.clone(), limb: before.leftLeg.rotation.clone(), focus: before.sceneryFocus.clone(), yaw: before.yaw, pitch: before.pitch, radius: before.sceneryRadius };
  assert.equal(f.api.enterPractice(), true); assert.equal(f.api.isPracticing, true); assert.equal(before.player.visible, true);
  near(before.player.position.y, .45 + 1.25 * Math.sin(Math.PI * (10 - 9.2) / 11.6), 'Bắt đầu đúng cao độ cầu');
  f.evaluate('keys.KeyD=true'); for (let i = 0; i < 20; i++) f.tick(.04); f.evaluate('keys.KeyD=false');
  assert.ok(before.player.position.distanceTo(saved.position) > .5);
  const ground = f.evaluate('bridgeHeight(player.position.x,player.position.z)'); near(before.player.position.y, ground, 'Di chuyển theo địa hình');
  vectorNear(before.sceneryFocus, before.player.position.clone().add(new T.Vector3(0, 1.1, 0)), 'Camera theo nhân vật');
  assert.equal(f.api.leavePractice(), true); const after = f.state();
  vectorNear(after.player.position, saved.position, 'Trả vị trí'); vectorNear(after.body.position, saved.bodyPosition, 'Trả bob vị trí thân');
  for (const axis of ['x', 'y', 'z']) { near(after.body.rotation[axis], saved.rotation[axis], 'Trả hướng thân'); near(after.leftLeg.rotation[axis], saved.limb[axis], 'Trả limb'); }
  assert.equal(after.player.visible, false); vectorNear(after.sceneryFocus, saved.focus, 'Trả focus');
  near(after.yaw, saved.yaw, 'Trả yaw'); near(after.pitch, saved.pitch, 'Trả pitch'); near(after.sceneryRadius, saved.radius, 'Trả radius');
  assert.equal(after.world.visible, false); assert.equal(after.housePreview.visible, true); assert.equal(after.gateView, 2); assert.equal(after.houseView, 3);
  assert.equal(f.ids.home.classList.contains('hidden'), false); assert.equal(f.ids.hud.style.display, 'none');
  assert.equal(f.api.isPracticing, false); f.api.dispose();
});

test('di chuyển giữ giới hạn canWalk và chặn lúc overlay/nội thất', () => {
  const f = fixture(); f.api.enterPractice(); const s = f.state();
  f.evaluate('yaw=0;player.position.set(23.95,.3,21);keys.KeyD=true'); f.tick(.2);
  assert.ok(s.player.position.x < 24.1, 'Không xuyên biên map');
  const saved = s.player.position.clone(); f.ids.quiz.classList.remove('hidden'); f.tick(.2);
  vectorNear(s.player.position, saved, 'Overlay chặn di chuyển'); assert.equal(f.api.cast(1).reason, 'overlay');
  f.ids.quiz.classList.add('hidden'); f.evaluate('insideHouse=true'); f.tick(.04);
  assert.equal(f.api.isPracticing, false); assert.equal(f.api.cast(1).reason, 'inside-house');
  f.api.dispose();
});

test('phím chiêu bỏ qua form/repeat/overlay/nội thất; cooldown chặn thi triển lặp', () => {
  const f = fixture(); f.api.enterPractice();
  const casts = () => f.events.filter(e => e.type === 'viet-village:skill-event' && e.detail.type === 'cast').length;
  for (const tagName of ['INPUT', 'SELECT', 'TEXTAREA']) f.key('Digit1', { target: { tagName } });
  f.key('Digit1', { target: { tagName: 'DIV', isContentEditable: true } }); f.key('Digit1', { repeat: true });
  assert.equal(casts(), 0);
  f.ids.quiz.classList.remove('hidden'); f.key('Digit1'); assert.equal(casts(), 0); f.ids.quiz.classList.add('hidden');
  f.evaluate('insideHouse=true'); f.key('Digit1'); assert.equal(casts(), 0); f.evaluate('insideHouse=false');
  assert.equal(f.key('Digit1'), true); assert.equal(casts(), 1); f.key('Digit1'); assert.equal(casts(), 1);
  assert.equal(f.api.cast(1).reason, 'cooldown');
  f.api.equip('sword'); assert.equal(f.key('Numpad1'), true); assert.equal(casts(), 2);
  f.api.equip('staff'); assert.equal(f.api.cast(1).reason, 'cooldown', 'Đổi vũ khí không làm mất cooldown cũ');
  f.api.dispose();
});

test('synchronise trang bị game, đổi chất lượng và nút bối cảnh kết thúc luyện chiêu', () => {
  const f = fixture(); f.api.enterPractice();
  f.state().player.userData.weaponId = 'axe'; f.tick(.04); assert.equal(f.api.weaponTip.name, 'axe-tip');
  f.api.cast(1); f.ids.quality.value = 'low'; f.ids.quality.dispatchEvent({ type: 'change' });
  assert.equal(f.api.manager.stats.quality, 'low'); assert.equal(f.api.manager.stats.active, 0);
  f.ids.cameraBtn.click(); assert.equal(f.api.isPracticing, false); assert.equal(f.state().player.visible, false);
  f.api.dispose();
});

test('thoát luyện chiêu không ghi đè Camera hoặc Nhà dân vừa chọn', () => {
  const f = fixture(); f.ids.home.classList.add('hidden');
  f.api.enterPractice(); f.ids.cameraBtn.click();
  assert.equal(f.api.isPracticing, false); const s = f.state();
  near(s.yaw, .55, 'Giữ yaw mới của Camera'); near(s.pitch, .67, 'Giữ pitch mới của Camera');
  near(s.sceneryRadius, 60, 'Giữ radius mới của Camera'); assert.equal(s.world.visible, true); assert.equal(s.housePreview.visible, false);
  vectorNear(s.sceneryFocus, new T.Vector3(0, 1, 0), 'Giữ focus mới của Camera');
  f.api.enterPractice(); f.ids.houseBtn.click();
  assert.equal(f.api.isPracticing, false); assert.equal(s.world.visible, false); assert.equal(s.housePreview.visible, true);
  vectorNear(s.sceneryFocus, new T.Vector3(11, 2, 0), 'Giữ focus Nhà dân vừa chọn');
  assert.equal(f.state().houseView, 0); f.api.dispose();
});

test('dispose giải phóng tài nguyên sở hữu, giữ scene/renderer/game objects và listener ngoài', () => {
  const f = fixture(), s = f.state(); const beforeChildren = [...s.scene.children];
  const geo = new T.BoxGeometry(), mat = new T.MeshBasicMaterial(), original = new T.Mesh(geo, mat); s.scene.add(original);
  let gameDisposals = 0, externalCalls = 0; geo.addEventListener('dispose', () => gameDisposals++); mat.addEventListener('dispose', () => gameDisposals++);
  f.context.addEventListener('keydown', () => externalCalls++);
  f.api.enterPractice(); f.api.cast(2); f.tick(.5);
  const owned = [], seen = new Set(); s.scene.traverse(node => { if (node === original) return; for (const resource of [node.geometry, ...(Array.isArray(node.material) ? node.material : [node.material])]) {
    if (!resource || seen.has(resource) || beforeChildren.includes(node)) continue; seen.add(resource);
    let count = 0; resource.addEventListener('dispose', () => count++); owned.push(() => assert.equal(count, 1, 'Tài nguyên VFX/model giải phóng đúng một lần'));
  } });
  f.api.dispose(); f.api.dispose(); owned.forEach(check => check());
  assert.equal(gameDisposals, 0); assert.deepEqual(s.scene.children, [...beforeChildren, original]);
  assert.equal(f.api.manager, null); assert.equal(f.api.caster, null); assert.equal(f.api.weaponTip, undefined);
  assert.equal(f.state().renderer, s.renderer); assert.equal(f.context.document.getElementById('vvw-panel'), null);
  f.key('Digit1'); assert.equal(externalCalls, 1); assert.equal(f.counts().rafCalls, 0);
  geo.dispose(); mat.dispose();
});

test('context tường minh hoạt động khi game mới không dùng tên lexical của bản nền', () => {
  const f = fixture(), scene = new T.Scene(), actor = new T.Group(), body = new T.Group(), hand = new T.Group();
  scene.add(actor); actor.add(body); body.add(hand); actor.visible = true;
  assert.equal(f.api.init({ THREE: T, scene, player: actor, body, hand, ground: () => 1.2, inside: () => false, blocked: () => false, playing: () => true }), true);
  assert.equal(f.api.manager.scene, scene); assert.equal(f.api.caster.parent, body);
  assert.equal(f.api.equip('bow').ok, true); assert.equal(f.api.cast(1).ok, true); f.api.update(.5);
  assert.equal(actor.userData.weaponId, 'bow'); assert.equal(f.api.enterPractice(), false, 'Không thay chế độ của game đang chạy');
  f.api.dispose(); assert.deepEqual(scene.children, [actor]);
});
