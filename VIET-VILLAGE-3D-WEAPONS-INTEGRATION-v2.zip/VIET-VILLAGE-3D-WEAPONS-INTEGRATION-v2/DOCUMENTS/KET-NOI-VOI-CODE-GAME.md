# Điểm nối VFX với game

## Vòng lặp dùng chung

Installer đặt các script classic trước `app.js`. Adapter nhận scene/nhân vật khi khung hình đầu của game gọi update; scene có thể chưa được tạo tại thời điểm tải script. Nó chỉ khởi tạo manager khi scene và nhân vật sẵn sàng.

Trong vòng lặp hiện có:

```js
// Game cập nhật nhân vật, camera, thời tiết và giao diện như trước.
if (window.VietVillageWeapons) window.VietVillageWeapons.update(dt);
renderer.render(scene, camera);
```

`dt` là giây đã được game tính. Không thêm `requestAnimationFrame` mới. Cài đặt không thay toàn bộ `app.js`; chỉ thêm lời gọi có marker để cài lại không trùng.

## Scene, trang bị và kỹ năng

`VietVillageWeapons.manager` là `WeaponVFXCore` đã nối vào scene thật. `caster` là đối tượng định hướng dưới body; `weaponTip` theo mẫu vũ khí trong tay phải. UI chọn vũ khí cập nhật `player.userData.weaponId` và điểm phát; đổi vũ khí hủy hiệu ứng đang chạy nhưng giữ hồi chiêu.

```js
VietVillageWeapons.equip('sword');
VietVillageWeapons.cast(3); // Kiếm Khí

// Nếu có điểm ngắm lấy từ raycast/game:
VietVillageWeapons.cast('sword.kiem-khi', targetWorldVector3);
```

Phím 1/2/3 được chặn khi nhập text/select, khi đang có overlay hoặc ở nội thất. Không dùng phím E cho đổi vũ khí vì game dùng tương tác cửa/câu đố. Nếu nhân vật bị ẩn, cần bật chế độ luyện chiêu hoặc dùng nhân vật đang chơi thật.

## Kết nối với chiến đấu sau này

```js
window.addEventListener('viet-village:skill-event', event => {
  const skill = event.detail;
  if (skill.type === 'impact') {
    // Combat của game kiểm tra địch, hitbox, damage và trạng thái trang bị.
    // skill.skillId, skill.position, skill.radius, skill.hitIndex...
  }
});

window.addEventListener('viet-village:weapon-equipped', event => {
  const { weaponId, player, weapon, tip } = event.detail;
  // Đồng bộ UI/trang bị hoặc thay model prototype bằng GLB đã rig.
});
```

Manager không tự giảm HP, tạo quái, giảm giáp hoặc bảo vệ. `impact` là mốc hình ảnh; các chiêu xoay có cửa sổ `activeSeconds`. Combat cần luật trúng và số hit riêng. Liên Tiễn có 3 mốc, Mưa Tên có 12 điểm rơi của bản thử.

Mẫu vũ khí đi kèm là hình học theo silhouette ảnh, chưa phải model khắc hoa văn/texture/rig final. Khi game có model thật, dùng `WeaponVFXCore` với bone/tip của model và equipment state thật; thay factory hình học hoặc viết binding riêng cho hệ thống nhân vật mới.

## Binding tùy chỉnh cho phiên bản game khác

Adapter có `init(context)` để nối rõ ràng khi game không dùng các biến nền. Context cần `THREE`, `scene`, `player`, `body`, `hand` và các hook như `ground(point)`, `blocked()`, `inside()`, `playing()`. Cách tự nhận diện của gói được kiểm thử cho bản classic nền; không tự giả định tên/rig của một bản game khác.

`VietVillageWeapons.dispose()` gỡ listener, model, caster và pool do adapter tạo. Nó không dispose scene, renderer, body hoặc material của game.

## Phạm vi thay đổi

| Thành phần | Tình trạng |
|---|---|
| Scene/camera/renderer của game | Dùng lại |
| Cập nhật VFX trong vòng lặp game | Đã chuẩn bị lời gọi cài đặt |
| Năm vũ khí và 15 chiêu | Có mã, mẫu hình khối và UI thử |
| Hướng nhìn và cao độ cầu/nền | Nối với body và bridgeHeight của bản nền |
| Firebase/đăng nhập/cơ sở dữ liệu | Không sửa bởi installer |
| HP/quái/hitbox/sát thương/miễn thương | Chưa có trong bản nền; cần code combat thật |
| Thư mục ổ H: của thầy | Chỉ được sửa khi thầy chạy installer trên máy |
