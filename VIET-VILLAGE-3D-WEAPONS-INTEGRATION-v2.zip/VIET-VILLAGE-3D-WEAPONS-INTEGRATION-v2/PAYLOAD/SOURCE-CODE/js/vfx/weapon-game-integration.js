/* Classic-script bridge for the exported VIET VILLAGE 3D scenery game.
 * Reads real lexical scene/player/body; updated by the EXISTING app tick.
 * No renderer, camera or requestAnimationFrame is created here.
 */
(function (root) {
  'use strict';
  if (root.VietVillageWeapons) return;
  let bound=null,manager=null,caster=null,mount=null,model=null,selected='staff',practice=null;
  let disposed=false,ui=null,lastMessage='Chọn vũ khí để thử chiêu trong làng.',configured=null;
  const listeners=[];
  const $=id=>document.getElementById(id);
  function listen(node,type,fn,options) {if(!node)return;node.addEventListener(type,fn,options);listeners.push(()=>node.removeEventListener(type,fn,options));}
  function say(message) {lastMessage=message;if(ui)ui.status.textContent=message;}
  function emit(type,detail) {if(typeof root.CustomEvent==='function')root.dispatchEvent(new root.CustomEvent(type,{detail}));}
  function automaticContext() {
    // These identifiers are lexical globals in the classic scripts, not window.scene.
    if(typeof scene==='undefined'||!scene?.isScene||typeof player==='undefined'||!player?.isObject3D||typeof body==='undefined'||!body?.isObject3D)return null;
    return {
      THREE:root.THREE,scene,player,body,hand:typeof rightArm==='undefined'?body:rightArm,
      ground:p=>typeof bridgeHeight==='function'?bridgeHeight(p.x,p.z):player.getWorldPosition(new root.THREE.Vector3()).y,
      inside:()=>typeof insideHouse!=='undefined'&&insideHouse,
      blocked:()=>typeof overlays==='function'&&overlays(),
      playing:()=>typeof active!=='undefined'&&active,
      clear:()=>{if(typeof clearMotion==='function')clearMotion();},
      keys:()=>typeof keys==='undefined'?{}:keys,
      view:()=>({yaw:typeof yaw==='undefined'?0:yaw,pitch:typeof pitch==='undefined'?.55:pitch,
        radius:typeof sceneryRadius==='undefined'?14:sceneryRadius,focus:typeof sceneryFocus==='undefined'?null:sceneryFocus.clone(),
        worldVisible:typeof world==='undefined'?null:world.visible,previewVisible:typeof housePreview==='undefined'?null:housePreview.visible,
        gate:typeof gateView==='undefined'?-1:gateView,house:typeof houseView==='undefined'?-1:houseView}),
      restoreView:v=>{if(typeof yaw!=='undefined')yaw=v.yaw;if(typeof pitch!=='undefined')pitch=v.pitch;if(typeof sceneryRadius!=='undefined')sceneryRadius=v.radius;
        if(typeof sceneryFocus!=='undefined'&&v.focus)sceneryFocus.copy(v.focus);if(typeof world!=='undefined'&&v.worldVisible!==null)world.visible=v.worldVisible;
        if(typeof housePreview!=='undefined'&&v.previewVisible!==null)housePreview.visible=v.previewVisible;if(typeof gateView!=='undefined')gateView=v.gate;if(typeof houseView!=='undefined')houseView=v.house;},
      startView:()=>{if(typeof world!=='undefined')world.visible=true;if(typeof housePreview!=='undefined')housePreview.visible=false;
        if(typeof gateView!=='undefined')gateView=-1;if(typeof houseView!=='undefined')houseView=-1;
        if(typeof sceneryRadius!=='undefined')sceneryRadius=14;if(typeof pitch!=='undefined')pitch=.42;if(typeof yaw!=='undefined')yaw=.28;},
      follow:()=>{if(typeof sceneryFocus!=='undefined')sceneryFocus.copy(player.position).add(new root.THREE.Vector3(0,1.1,0));},
      walkable:(x,z)=>typeof canWalk!=='function'||canWalk(x,z),
      limbs:{leftLeg:typeof leftLeg==='undefined'?null:leftLeg,rightLeg:typeof rightLeg==='undefined'?null:rightLeg,
        leftArm:typeof leftArm==='undefined'?null:leftArm,rightArm:typeof rightArm==='undefined'?null:rightArm}
    };
  }
  function getContext() {return configured||(automaticContext());}
  function teardown() {
    if(manager)manager.dispose();manager=null;
    if(model)model.dispose();model=null;
    if(mount)mount.removeFromParent();mount=null;if(caster)caster.removeFromParent();caster=null;bound=null;
  }
  function attach() {
    if(disposed)return false;
    const ctx=getContext();
    if(!ctx?.THREE||!ctx.scene?.isScene||!ctx.player?.isObject3D||!ctx.body?.isObject3D||!root.WeaponVFXCore||!root.WeaponPreviewModels)return false;
    if(bound?.scene===ctx.scene&&bound.player===ctx.player&&bound.body===ctx.body)return true;
    teardown();bound=ctx;
    caster=new ctx.THREE.Object3D();caster.name='viet-village-weapon-caster';caster.rotation.y=Math.PI;ctx.body.add(caster);
    mount=new ctx.THREE.Group();mount.name='viet-village-weapon-hand';mount.position.set(0,-.56,0);(ctx.hand||ctx.body).add(mount);
    const existing=ctx.player.userData.weaponId;
    if(root.WeaponVFXCore.getWeaponConfigs().some(c=>c.weaponId===existing))selected=existing;
    manager=new root.WeaponVFXCore({THREE:ctx.THREE,scene:ctx.scene,quality:quality(),getGroundY:ctx.ground||(()=>0),
      getEquippedWeapon:()=>ctx.player.userData.weaponId,
      onEvent:event=>{emit('viet-village:skill-event',event);if(event.type==='cast')say('Đang thi triển '+profile().skills.find(s=>s.id===event.skillId)?.name+'.');}});
    equip(selected);return true;
  }
  function quality() {const value=$('quality')?.value;return value==='low'?'low':value==='high'?'high':'medium';}
  function profile() {return root.WeaponVFXCore?.getWeaponConfigs().find(c=>c.weaponId===selected);}
  function equip(id) {
    const p=root.WeaponVFXCore?.getWeaponConfigs().find(c=>c.weaponId===id);if(!p)return {ok:false,reason:'unknown-weapon'};
    selected=id;if(!bound){if(ui)refresh();return {ok:true,weaponId:id};}
    manager.cancelAll();if(model)model.dispose();model=root.WeaponPreviewModels.create(bound.THREE,id);mount.add(model.group);
    model.group.rotation.x=id==='staff'?0:id==='bow'?0:.22;model.group.rotation.y=id==='bow'?Math.PI:0;
    bound.player.userData.weaponId=id;caster.userData.weaponId=id;
    if(ui)refresh();emit('viet-village:weapon-equipped',{weaponId:id,player:bound.player,weapon:model.group,tip:model.tip});
    say('Đã chọn '+p.name+'.');return {ok:true,weaponId:id};
  }
  function cast(slot,point=null) {
    if(!attach())return {ok:false,reason:'game-not-ready'};
    if(bound.inside?.()) {say('Ra sân để thi triển chiêu.');return {ok:false,reason:'inside-house'};}
    if(bound.blocked?.())return {ok:false,reason:'overlay'};
    if(!bound.player.visible){say('Bấm “Bắt đầu luyện chiêu” để hiện nhân vật.');return {ok:false,reason:'hidden-caster'};}
    const skill=typeof slot==='string'?profile().skills.find(s=>s.id===slot||s.localId===slot):profile().skills.find(s=>s.slot===slot);
    if(!skill)return {ok:false,reason:'unknown-skill'};
    const result=manager.cast(skill.id,{caster,weaponTip:model.tip,point});
    if(!result.ok)say(result.reason==='cooldown'?'Chiêu đang hồi: '+result.retryAfter.toFixed(1)+' giây.':'Chưa thi triển được: '+result.reason+'.');
    return result;
  }
  function enterPractice() {
    if(!attach()){say('Cảnh 3D chưa sẵn sàng. Hãy mở game trước.');return false;}
    if(bound.inside?.()){say('Ra sân rồi bắt đầu luyện chiêu.');return false;}
    if(bound.playing?.()){say('Nhân vật đang hoạt động; chọn chiêu để thi triển.');return false;}
    if(practice)return true;
    const T=bound.THREE,limbs=Object.values(bound.limbs||{}).filter(Boolean);
    const home=$('home'),hud=$('hud');
    practice={position:bound.player.position.clone(),visible:bound.player.visible,bodyPosition:bound.body.position.clone(),
      bodyRotation:bound.body.rotation.clone(),view:bound.view?.(),limbs:limbs.map(node=>({node,rotation:node.rotation.clone()})),
      homeHidden:home?.classList.contains('hidden'),hudDisplay:hud?.style.display};
    bound.clear?.();bound.player.visible=true;bound.body.rotation.y=Math.PI;
    const p=bound.player.getWorldPosition(new T.Vector3());bound.player.position.y=(bound.ground||(()=>p.y))(p);
    if(home)home.classList.add('hidden');if(hud)hud.style.display='block';bound.startView?.();bound.follow?.();
    if(ui)ui.start.textContent='Kết thúc luyện chiêu';say('Luyện chiêu trong làng · WASD để di chuyển · phím 1/2/3 để thi triển.');return true;
  }
  function leavePractice({restoreView=true}={}) {
    if(!practice)return false;
    const saved=practice;practice=null;manager?.cancelAll();bound?.clear?.();
    if(bound){bound.player.position.copy(saved.position);bound.player.visible=saved.visible;bound.body.position.copy(saved.bodyPosition);bound.body.rotation.copy(saved.bodyRotation);
      for(const item of saved.limbs)item.node.rotation.copy(item.rotation);if(restoreView&&saved.view)bound.restoreView?.(saved.view);}
    const home=$('home'),hud=$('hud');if(restoreView){if(home&&saved.homeHidden!==undefined)home.classList.toggle('hidden',saved.homeHidden);
      if(hud&&saved.hudDisplay!==undefined)hud.style.display=saved.hudDisplay;}
    if(ui)ui.start.textContent='Bắt đầu luyện chiêu';say('Đã kết thúc luyện chiêu.');return true;
  }
  function movePractice(dt) {
    if(!practice||bound.playing?.())return;
    const k=bound.keys?.()||{},view=bound.view?.()||{yaw:0};
    const ix=(k.KeyD||k.ArrowRight?1:0)-(k.KeyA||k.ArrowLeft?1:0),iz=(k.KeyS||k.ArrowDown?1:0)-(k.KeyW||k.ArrowUp?1:0);
    const dx=ix*Math.cos(view.yaw)+iz*Math.sin(view.yaw),dz=-ix*Math.sin(view.yaw)+iz*Math.cos(view.yaw),length=Math.hypot(dx,dz);
    if(length>.01){const speed=k.ShiftLeft||k.ShiftRight?6.5:4.5,p=bound.player.position,x=p.x,z=p.z;
      p.x+=dx/length*speed*dt;p.z+=dz/length*speed*dt;
      if(bound.walkable&&!bound.walkable(p.x,p.z)){if(bound.walkable(p.x,z))p.z=z;else if(bound.walkable(x,p.z))p.x=x;else{p.x=x;p.z=z;}}
      p.y=bound.ground?bound.ground(bound.player.getWorldPosition(new bound.THREE.Vector3())):p.y;
      const desired=Math.atan2(dx,dz);bound.body.rotation.y+=Math.atan2(Math.sin(desired-bound.body.rotation.y),Math.cos(desired-bound.body.rotation.y))*Math.min(1,dt*12);
      const wave=Math.sin(manager.time*11)*.45;for(const [name,node] of Object.entries(bound.limbs||{}))if(node)node.rotation.x=name==='leftLeg'?wave:name==='rightLeg'?-wave:name==='rightArm'?-.25:-wave*.4;
    } else for(const node of Object.values(bound.limbs||{}))if(node)node.rotation.x*=.8;
    bound.follow?.();
  }
  function update(dt) {
    if(disposed||!attach())return;
    if(bound.inside?.()||practice&&!bound.player.visible){leavePractice({restoreView:false});manager.cancelAll();return;}
    const external=bound.player.userData.weaponId;
    if(external!==selected&&root.WeaponVFXCore.getWeaponConfigs().some(c=>c.weaponId===external))equip(external);
    if(!bound.blocked?.()){movePractice(dt);manager.update(dt);}
    if(ui)for(const item of ui.skills){const remaining=manager.cooldownRemaining(item.skill.id,caster);item.button.textContent=item.skill.slot+' · '+item.skill.name+(remaining>0?' ('+remaining.toFixed(1)+'s)':'');item.button.disabled=remaining>0;}
  }
  function refresh() {
    if(!ui)return;ui.select.value=selected;ui.skills=[];ui.list.replaceChildren();
    for(const skill of profile()?.skills||[]){const button=document.createElement('button');button.type='button';button.className='vvw-skill';button.textContent=skill.slot+' · '+skill.name;
      button.addEventListener('click',()=>cast(skill.slot));ui.list.appendChild(button);ui.skills.push({skill,button});}
  }
  function mountUI() {
    if(ui||disposed||!document.body)return;
    const open=document.createElement('button');open.type='button';open.className='vvw-open';open.id='vvw-open';open.textContent='⚔ Vũ khí · Chiêu thức';
    const tools=document.querySelector('#hud .tools');if(tools)tools.appendChild(open);else{open.classList.add('vvw-floating');document.body.appendChild(open);}
    const panel=document.createElement('section');panel.id='vvw-panel';panel.className='vvw-panel';panel.hidden=true;panel.setAttribute('aria-label','Vũ khí và chiêu thức');
    const header=document.createElement('div');header.className='vvw-heading';const title=document.createElement('strong');title.textContent='VŨ KHÍ · CHIÊU THỨC';
    const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Thu gọn bảng chiêu');header.append(title,close);
    const label=document.createElement('label');label.textContent='Vũ khí đang cầm';const select=document.createElement('select');select.setAttribute('aria-label','Chọn vũ khí');
    for(const p of root.WeaponVFXCore?.getWeaponConfigs()||[]){const option=document.createElement('option');option.value=p.weaponId;option.textContent=p.name;select.appendChild(option);}label.appendChild(select);
    const start=document.createElement('button');start.type='button';start.className='vvw-start';start.textContent='Bắt đầu luyện chiêu';
    const list=document.createElement('div');list.className='vvw-skills';const status=document.createElement('p');status.className='vvw-status';status.setAttribute('role','status');status.textContent=lastMessage;
    const note=document.createElement('small');note.textContent='Phím 1 / 2 / 3: thi triển. Đổi vũ khí sẽ dừng chiêu đang chạy.';
    panel.append(header,label,start,list,status,note);document.body.appendChild(panel);ui={open,panel,select,start,list,status,skills:[]};
    listen(open,'click',()=>{panel.hidden=!panel.hidden;open.setAttribute('aria-expanded',String(!panel.hidden));attach();});
    listen(close,'click',()=>{panel.hidden=true;open.setAttribute('aria-expanded','false');});listen(select,'change',()=>equip(select.value));
    listen(start,'click',()=>practice?leavePractice():enterPractice());
    listen(root,'keydown',event=>{if(event.repeat||['INPUT','SELECT','TEXTAREA'].includes(event.target?.tagName)||event.target?.isContentEditable)return;
      const slot={Digit1:1,Digit2:2,Digit3:3,Numpad1:1,Numpad2:2,Numpad3:3}[event.code];if(slot&&bound?.player.visible&&!bound.inside?.()&&!bound.blocked?.()){event.preventDefault();cast(slot);}});
    listen($('quality'),'change',()=>manager?.setQuality(quality()));
    for(const id of ['overviewBtn','cameraBtn','gateBtn','houseBtn','enterHouseBtn'])listen($(id),'click',()=>leavePractice(),{capture:true});
    listen(root,'pagehide',()=>api.dispose());refresh();
  }
  const api={
    init(context=null){if(context)configured=context;return attach();},update,equip,cast,enterPractice,leavePractice,
    get manager(){return manager;},get caster(){return caster;},get weaponTip(){return model?.tip;},get isPracticing(){return !!practice;},
    show(){if(ui){ui.panel.hidden=false;ui.open.setAttribute('aria-expanded','true');}},
    dispose(){if(disposed)return;leavePractice();disposed=true;teardown();for(const off of listeners)off();listeners.length=0;ui?.panel.remove();ui?.open.remove();ui=null;}
  };
  root.VietVillageWeapons=api;mountUI();
})(typeof window!=='undefined'?window:globalThis);
