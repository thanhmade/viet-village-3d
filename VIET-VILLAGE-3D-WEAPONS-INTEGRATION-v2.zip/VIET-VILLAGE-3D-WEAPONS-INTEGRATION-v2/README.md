# Cài 15 chiêu vào bản thử VIET VILLAGE 3D

Gói này nối bộ VFX vào **cảnh và nhân vật đang có của game**, dùng renderer và vòng lặp hiện có. Đây là gói cài đặt, khác với sân demo độc lập của gói VFX trước.

Thư mục đích mặc định:

```text
H:\CHAT GPT\3D-GAME\VIET-VILLAGE-3D\VIET-VILLAGE-3D-CAP-NHAT
```

## Cài trên máy thầy

1. Giải nén toàn bộ gói này vào một thư mục riêng, ví dụ `H:\CHAT GPT\3D-GAME\VFX-INSTALL`. Giữ `INSTALL-WEAPONS-VFX.cjs`, file BAT và `PAYLOAD` cùng cấp.
2. Chạy **`CAI-VFX-VAO-CAP-NHAT.bat`**. Máy cần có Node.js; nếu game đã cài dependencies bằng npm thì thường Node đã có sẵn. File BAT không tự tải hoặc cài Node.
3. Đọc kết quả: installer kiểm tra cấu trúc, sao lưu rồi cài vào đúng thư mục CAP-NHAT. Nếu báo không khớp, nó dừng trước khi sửa mã. Không cần chép đè cả dự án hoặc thay root `index.html`.
4. Mở **`START-SERVER.bat` của thư mục CAP-NHAT** như trước, vào game, bấm **Xem bối cảnh 3D**, rồi **Vũ khí · Chiêu thức → Bắt đầu luyện chiêu**.
5. Chọn Côn/Gậy, Kiếm, Thương/Giáo, Cung hoặc Rìu; bấm chiêu hoặc phím **1/2/3**. Trong luyện chiêu dùng WASD/mũi tên, Shift để đi nhanh; xoay camera bằng thao tác game sẵn có. Bấm **Kết thúc luyện chiêu** để trở về trạng thái xem bối cảnh trước đó.

Cài vào vị trí khác hoặc xem trước, mở terminal tại thư mục gói:

```bat
node INSTALL-WEAPONS-VFX.cjs "H:\CHAT GPT\3D-GAME\VIET-VILLAGE-3D\VIET-VILLAGE-3D-CAP-NHAT" --dry-run
node INSTALL-WEAPONS-VFX.cjs "H:\CHAT GPT\3D-GAME\VIET-VILLAGE-3D\VIET-VILLAGE-3D-CAP-NHAT"
```

## File sẽ vào đâu

Các đường dẫn sau tính từ **CAP-NHAT**:

| Đường dẫn | Nội dung hoặc thay đổi |
|---|---|
| `SOURCE-CODE/js/vfx/weapon-vfx-core.js` | Bộ xử lý VFX dùng chung |
| `SOURCE-CODE/js/vfx/{staff,sword,spear,bow,axe}-skill-config.js` | Năm bộ tên, mã và thông số chiêu |
| `SOURCE-CODE/js/vfx/{staff,sword,spear,bow,axe}-skill-vfx.js` | Năm bộ đăng ký hiệu ứng |
| `SOURCE-CODE/js/vfx/weapon-preview-models.js` | Năm mẫu vũ khí hình học gắn vào tay nhân vật |
| `SOURCE-CODE/js/vfx/weapon-game-integration.js` | Nối scene, hướng nhân vật, điểm phát và bảng điều khiển |
| `SOURCE-CODE/css/weapon-integration.css` | Giao diện chọn vũ khí và chiêu |
| `SOURCE-CODE/index.html` | Thêm CSS/script theo thứ tự |
| `SOURCE-CODE/js/app.js` | Thêm một lời gọi update trong vòng lặp đang có |
| `ASSETS/reference/{weapon}/` | Mười PNG gốc, mỗi vũ khí hai ảnh |
| `BACKUP/…` | Sao lưu các file bị thay đổi và danh sách phục hồi do installer tạo |

Installer giữ nguyên root `index.html`, `README.md`, file khởi động, cấu hình Firebase và `package.json`; không có thao tác Git/push/merge. Cài lại cùng gói không tạo thêm thẻ script hoặc thêm vòng lặp.

## Cách kết nối đã được chuẩn bị

Đọc bản nguồn nền đã có trong phiên làm việc: Three.js r160, `scene`, `player`, `body`, `rightArm` và `bridgeHeight(x,z)`. Các biến đó là biến cấp script cổ điển, không phải `window.scene`. Adapter dùng đúng scene đã tồn tại và điểm tay phải; không tạo canvas/camera/renderer/RAF khác.

Nhân vật nền quay theo **+Z**, VFX dùng **−Z**. Adapter thêm một đối tượng định hướng dưới `body`, xoay Y 180°, để chiêu theo hướng nhân vật. Cập nhật VFX diễn ra trước `renderer.render(scene,camera)` trong `tick` của game. Độ cao nền lấy từ hàm nền/cầu thật của game.

Bản nguồn nền hiện là bản dựng bối cảnh: nhân vật bị ẩn, vòng chơi ARPG chưa bật và chưa có HP/quái/hitbox. Vì vậy đã thêm chế độ luyện chiêu trong **làng thật** để hiện nhân vật/vũ khí, thử 15 chiêu và trả lại trạng thái sau khi thoát. Sự kiện chiêu được phát cho code chiến đấu nối tiếp; sát thương, giảm giáp và miễn thương chưa tự xuất hiện.

## Phiên bản trên máy và phục hồi

Ảnh thư mục có Firebase và các cập nhật mới; chưa có toàn bộ `SOURCE-CODE` mới của ổ H: trong phiên này. Bản nguồn nền được dùng để xác định điểm nối và kiểm thử, **không được coi là bản mới nhất trên máy thầy**. Installer kiểm tra mã trước khi vá; cấu trúc khác sẽ được báo rõ để dùng mã nguồn hiện tại thay vì chép đè `app.js` cũ.

Sau khi cài, đường dẫn sao lưu được in trong terminal. Có thể phục hồi bằng:

```bat
node INSTALL-WEAPONS-VFX.cjs "H:\CHAT GPT\3D-GAME\VIET-VILLAGE-3D\VIET-VILLAGE-3D-CAP-NHAT" --restore "DUONG-DAN-SAO-LUU-DUOC-IN-RA"
```

Nếu installer dừng vì cấu trúc game khác, cần xem bản `SOURCE-CODE/index.html`, `SOURCE-CODE/js/app.js` và các file hiện tạo scene/nhân vật của CAP-NHAT. `index.html` ở thư mục gốc chỉ chuyển hướng nên không đủ để sửa chính xác phần game.

Trong phiên này tôi chưa truy cập hoặc ghi trực tiếp vào ổ H:, và chưa chạy trình duyệt trên máy thầy. Xem kết quả kiểm tra gói trong `DOCUMENTS/VALIDATION.md`. Không cần đưa bản thử lên GitHub để xem các chiêu.
