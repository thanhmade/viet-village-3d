#!/usr/bin/env node
'use strict';
// Offline installer: only managed VFX files and two validated game entry files.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');

const DEFAULT_TARGET = 'H:\\CHAT GPT\\3D-GAME\\VIET-VILLAGE-3D\\VIET-VILLAGE-3D-CAP-NHAT';
const WEAPONS = ['staff', 'sword', 'spear', 'bow', 'axe'];
const SCRIPTS = ['weapon-vfx-core.js', ...WEAPONS.flatMap(w => [w + '-skill-config.js', w + '-skill-vfx.js']), 'weapon-preview-models.js', 'weapon-game-integration.js'];
const REQUIRED = ['SOURCE-CODE/css/weapon-integration.css', ...SCRIPTS.map(f => 'SOURCE-CODE/js/vfx/' + f)];
const ENTRY_FILES = ['SOURCE-CODE/index.html', 'SOURCE-CODE/js/app.js'];
const MARKERS = {
  scripts: ['<!-- VIET-VILLAGE-WEAPONS:BEGIN -->', '<!-- VIET-VILLAGE-WEAPONS:END -->'],
  style: ['<!-- VIET-VILLAGE-WEAPONS:STYLE:BEGIN -->', '<!-- VIET-VILLAGE-WEAPONS:STYLE:END -->'],
  update: ['/* VIET-VILLAGE-WEAPONS:UPDATE:BEGIN */', '/* VIET-VILLAGE-WEAPONS:UPDATE:END */']
};
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const normalize = p => process.platform === 'win32' ? path.resolve(p).toLowerCase() : path.resolve(p);
const relativeName = p => p.split(path.sep).join('/');
function error(message) { throw new Error(message); }
function allowedPayload(name) {
  return /^SOURCE-CODE\/js\/vfx\/[a-z0-9-]+\.js$/.test(name) || name === 'SOURCE-CODE/css/weapon-integration.css' || /^ASSETS\/reference\/[a-z0-9-]+\/[a-z0-9-]+\.png$/.test(name);
}
function assertRelative(name) {
  if (typeof name !== 'string' || !name || name.includes('\\') || path.isAbsolute(name) || name.split('/').some(p => !p || p === '.' || p === '..')) error('Đường dẫn không hợp lệ trong gói/backup: ' + name);
}
function contained(root, filename) {
  const rel = path.relative(root, filename);
  if (rel === '..' || rel.startsWith('..' + path.sep) || path.isAbsolute(rel)) error('Đường dẫn nằm ngoài thư mục đích: ' + filename);
}
function safePath(root, name) {
  assertRelative(name);
  const filename = path.join(root, ...name.split('/'));
  contained(root, filename);
  let current = root;
  for (const segment of name.split('/')) {
    current = path.join(current, segment);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) error('Từ chối đường dẫn liên kết/junction: ' + current);
  }
  return filename;
}
function readUtf8(filename) {
  const bytes = fs.readFileSync(filename);
  try { new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes); } catch (_) { error('Tệp phải dùng UTF-8: ' + filename); }
  return { bytes, text: bytes.toString('utf8') };
}
function eol(text) { return (text.match(/\r\n|\n|\r/) || ['\n'])[0]; }
function stripManaged(text, pair) {
  const [begin, end] = pair;
  const starts = text.split(begin).length - 1, ends = text.split(end).length - 1;
  if (!starts && !ends) return text;
  if (starts !== 1 || ends !== 1) error('Marker VFX bị thiếu hoặc trùng: ' + begin);
  const start = text.indexOf(begin), finish = text.indexOf(end);
  if (finish < start) error('Marker VFX sai thứ tự: ' + begin);
  let after = finish + end.length;
  if (text.slice(after, after + 2) === '\r\n') after += 2;
  else if (text[after] === '\n' || text[after] === '\r') after++;
  return text.slice(0, start) + text.slice(after);
}
function attributes(raw) {
  const out = Object.create(null);
  const re = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  let match;
  while ((match = re.exec(raw))) {
    const key = match[1].toLowerCase();
    if (Object.hasOwn(out, key)) error('Thuộc tính HTML bị trùng: ' + key);
    out[key] = match[2] ?? match[3] ?? match[4] ?? '';
  }
  return out;
}
function scriptTags(html) {
  const tags = [], re = /<script\b([^>]*)>[\s\S]*?<\/script\s*>/gi;
  let match;
  while ((match = re.exec(html))) tags.push({ text: match[0], attrs: attributes(match[1]), index: match.index });
  return tags;
}
// Keep positions stable while excluding strings/comments from hook matching.
function maskJavaScript(text) {
  const chars = text.split('');
  let i = 0;
  function erase(index) { if (chars[index] !== '\n' && chars[index] !== '\r') chars[index] = ' '; }
  while (i < text.length) {
    const c = text[i], next = text[i + 1];
    if (c === '/' && (next === '/' || next === '*')) {
      const line = next === '/'; erase(i++); erase(i++);
      while (i < text.length) {
        if (line && (text[i] === '\n' || text[i] === '\r')) break;
        if (!line && text[i] === '*' && text[i + 1] === '/') { erase(i++); erase(i++); break; }
        erase(i++);
      }
    } else if (c === '"' || c === "'" || c === '`') {
      const quote = c; erase(i++);
      while (i < text.length) {
        if (text[i] === '\\') { erase(i++); if (i < text.length) erase(i++); }
        else if (text[i] === quote) { erase(i++); break; }
        else erase(i++);
      }
    } else i++;
  }
  return chars.join('');
}
function loadedSources(root, tags, appIndex) {
  let combined = '';
  for (const tag of tags) {
    if (tag.index >= appIndex || !tag.attrs.src || /^(?:https?:|\/\/|data:)/i.test(tag.attrs.src)) continue;
    const src = tag.attrs.src.split(/[?#]/)[0];
    if (src.includes('\\') || path.isAbsolute(src)) error('Script nền phải dùng đường dẫn tương đối: ' + src);
    const filename = path.resolve(root, 'SOURCE-CODE', src);
    contained(root, filename);
    const rel = relativeName(path.relative(root, filename));
    safePath(root, rel);
    if (!fs.existsSync(filename) || !fs.statSync(filename).isFile()) error('Thiếu script nền đang được HTML nạp: ' + rel);
    combined += '\n' + maskJavaScript(readUtf8(filename).text);
  }
  return combined;
}
function validateApp(app, loaded) {
  try { new vm.Script(app, { filename: 'SOURCE-CODE/js/app.js' }); } catch (e) { error('app.js không hợp lệ: ' + e.message); }
  const code = maskJavaScript(app);
  if (/\bVietVillageWeapons\s*\.\s*update\s*\(/.test(code)) error('app.js đã có update VFX ngoài marker. Hãy bỏ hook thủ công hoặc phục hồi trước khi cài.');
  const allRender = [...code.matchAll(/\brenderer\s*\.\s*render\s*\(/g)];
  const exactRender = [...code.matchAll(/\brenderer\.render\(scene,camera\);/g)];
  if (allRender.length !== 1 || exactRender.length !== 1) error('Không xác định được điểm nối an toàn: app.js phải có đúng một renderer.render(scene,camera);. Chưa sửa tệp nào.');
  const tick = /\bfunction\s+tick\s*\(\s*ms\s*\)\s*\{/.exec(code);
  if (!tick || (code.match(/\bfunction\s+tick\s*\(/g) || []).length !== 1) error('Không tìm thấy đúng một function tick(ms) của game nền.');
  let depth = 1, end = tick.index + tick[0].length;
  while (end < code.length && depth) { if (code[end] === '{') depth++; if (code[end] === '}') depth--; end++; }
  const renderIndex = exactRender[0].index;
  if (depth || renderIndex < tick.index + tick[0].length || renderIndex >= end - 1) error('renderer.render không nằm trong tick(ms), không thể tự nối VFX.');
  const tickBody = code.slice(tick.index, end);
  if (!/\b(?:let|const|var)\s+dt\s*=/.test(tickBody) || !/\brequestAnimationFrame\s*\(\s*tick\s*\)/.test(tickBody)) error('tick(ms) không có dt hoặc vòng lặp nền tương thích.');
  const combined = loaded + '\n' + code;
  for (const name of ['renderer', 'scene', 'player', 'body', 'rightArm', 'sceneryFocus', 'sceneryRadius']) {
    const declaration = new RegExp('\\b(?:let|const|var)\\s+[^;{}\\n]*\\b' + name + '\\s*(?=[,;=])');
    if (!declaration.test(combined)) error('Game nền thiếu khai báo ' + name + '; bản này chưa tương thích để tự cài.');
  }
  if (!/\bplayer\s*=\s*new\s+THREE\s*\.\s*Group\s*\(/.test(loaded) || !/\bbody\s*=\s*new\s+THREE\s*\.\s*Group\s*\(/.test(loaded) || !/\bscene\s*=\s*new\s+THREE\s*\.\s*Scene\s*\(/.test(loaded)) error('Không tìm thấy khởi tạo scene/player/body của game nền.');
  for (const name of ['bridgeHeight', 'canWalk']) {
    const signature = new RegExp('\\bfunction\\s+' + name + '\\s*\\(\\s*x\\s*,\\s*z\\s*\\)\\s*\\{');
    if (!signature.test(loaded)) error('Game nền thiếu function ' + name + '(x,z); chưa thể nối chính xác độ cao/mặt đất hoặc va chạm.');
  }
  return renderIndex;
}
function patchEntries(root) {
  const htmlRead = readUtf8(safePath(root, ENTRY_FILES[0]));
  const appRead = readUtf8(safePath(root, ENTRY_FILES[1]));
  let html = stripManaged(stripManaged(htmlRead.text, MARKERS.scripts), MARKERS.style);
  const app = stripManaged(appRead.text, MARKERS.update);
  const tags = scriptTags(html);
  const appTags = tags.filter(tag => /^(?:\.\/)?js\/app\.js$/.test(tag.attrs.src || ''));
  if (appTags.length !== 1) error('SOURCE-CODE/index.html phải nạp đúng một ./js/app.js.');
  const appTag = appTags[0];
  if (Object.hasOwn(appTag.attrs, 'async') || Object.hasOwn(appTag.attrs, 'defer') || (appTag.attrs.type && !/^(?:text|application)\/javascript$/i.test(appTag.attrs.type))) error('app.js phải là classic script, không async/defer/module.');
  for (const tag of tags) {
    const basename = (tag.attrs.src || '').split(/[?#]/)[0].split('/').pop();
    if (SCRIPTS.includes(basename) || /^(?:staff|sword|spear|bow|axe)-skill-(?:config|vfx)\.js$/.test(basename)) error('Đã có script VFX ngoài khối managed: ' + tag.attrs.src + '. Dừng để tránh nạp hai lần; gỡ tag thủ công rồi chạy lại.');
  }
  const existingStyles = [...html.matchAll(/<link\b([^>]*)>/gi)].filter(m => /(?:^|\/)weapon-integration\.css(?:[?#].*)?$/.test(attributes(m[1]).href || ''));
  if (existingStyles.length) error('Đã có weapon-integration.css ngoài marker; gỡ link thủ công trước khi cài để tránh trùng.');
  if ((html.match(/<\/head\s*>/gi) || []).length !== 1) error('HTML phải có đúng một </head>.');
  const loaded = loadedSources(root, tags, appTag.index);
  const localThree = safePath(root, 'ASSETS/vendor/three.min.js');
  const threeTags = tags.filter(tag => /(?:^|\/)three(?:\.min)?\.js(?:[?#].*)?$/i.test(tag.attrs.src || '') && tag.index < appTag.index);
  if (!fs.existsSync(localThree) && !threeTags.length) error('Game chưa có Three.js; gói nối không nạp thêm engine.');
  if (!threeTags.length) error('HTML chưa nạp Three.js trước app.js; không thể nối an toàn.');
  if (threeTags.length !== 1) error('HTML đang nạp nhiều bản Three.js; cần giữ đúng một engine trước khi nối VFX.');
  if (threeTags.some(tag => Object.hasOwn(tag.attrs, 'async') || Object.hasOwn(tag.attrs, 'defer') || (tag.attrs.type && !/^(?:text|application)\/javascript$/i.test(tag.attrs.type)))) error('Three.js phải được nạp bằng classic script trước VFX.');
  const renderIndex = validateApp(app, loaded);
  const htmlNL = eol(htmlRead.text), appNL = eol(appRead.text);
  const block = [MARKERS.scripts[0], ...SCRIPTS.map(file => '<script src="./js/vfx/' + file + '"></script>'), MARKERS.scripts[1], ''].join(htmlNL);
  html = html.slice(0, appTag.index) + block + html.slice(appTag.index);
  const styles = [MARKERS.style[0], '<link rel="stylesheet" href="./css/weapon-integration.css">', MARKERS.style[1], ''].join(htmlNL);
  html = html.replace(/<\/head\s*>/i, match => styles + match);
  const hook = [MARKERS.update[0], 'if (window.VietVillageWeapons) window.VietVillageWeapons.update(dt);', MARKERS.update[1], ''].join(appNL);
  return [
    { name: ENTRY_FILES[0], bytes: Buffer.from(html, 'utf8') },
    { name: ENTRY_FILES[1], bytes: Buffer.from(app.slice(0, renderIndex) + hook + app.slice(renderIndex), 'utf8') }
  ];
}
function payloadFiles(packageRoot) {
  const payload = path.join(packageRoot, 'PAYLOAD');
  if (!fs.existsSync(payload) || !fs.statSync(payload).isDirectory()) error('Thiếu PAYLOAD trong gói nối.');
  const result = [];
  function visit(dir) {
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      const filename = path.join(dir, item.name), name = relativeName(path.relative(payload, filename));
      if (item.isSymbolicLink()) error('PAYLOAD có liên kết không được hỗ trợ: ' + name);
      if (item.isDirectory()) visit(filename);
      else if (item.isFile()) {
        assertRelative(name);
        if (!allowedPayload(name)) error('PAYLOAD không được phép ghi tệp này: ' + name);
        result.push({ name, bytes: fs.readFileSync(filename) });
      } else error('PAYLOAD có loại tệp không được hỗ trợ: ' + name);
    }
  }
  visit(payload);
  const found = new Set(result.map(item => item.name));
  for (const name of REQUIRED) if (!found.has(name)) error('Thiếu tệp PAYLOAD bắt buộc: ' + name + '. Chưa sửa tệp nào.');
  return result.sort((a, b) => a.name.localeCompare(b.name));
}
function targetRoot(target) {
  const requested = path.resolve(target);
  if (!fs.existsSync(requested) || !fs.statSync(requested).isDirectory()) error('Không thấy thư mục game đích: ' + target + '\nHãy chạy trên máy có thư mục H: này, hoặc truyền --target đường-dẫn-game-test.');
  return fs.realpathSync(requested);
}
function snapshot(root, name) {
  const filename = safePath(root, name);
  if (!fs.existsSync(filename)) return { name, filename, existed: false, bytes: null, mode: 0o644 };
  if (!fs.statSync(filename).isFile()) error('Đích phải là tệp thường: ' + name);
  return { name, filename, existed: true, bytes: fs.readFileSync(filename), mode: fs.statSync(filename).mode & 0o777 };
}
function missingDirectories(root, names) {
  const result = new Set();
  for (const name of names) {
    let dir = path.dirname(safePath(root, name));
    while (dir !== root && !fs.existsSync(dir)) { result.add(relativeName(path.relative(root, dir))); dir = path.dirname(dir); }
  }
  return [...result].sort((a, b) => a.split('/').length - b.split('/').length);
}
function atomicWrite(filename, bytes, mode) {
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  const temporary = filename + '.vfx-tmp-' + process.pid + '-' + crypto.randomBytes(5).toString('hex');
  try { fs.writeFileSync(temporary, bytes, { flag: 'wx', mode }); fs.renameSync(temporary, filename); }
  finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
}
function removeEmptyDirectories(root, names) {
  for (const name of [...names].reverse()) {
    const dir = safePath(root, name);
    if (fs.existsSync(dir) && fs.statSync(dir).isDirectory() && !fs.readdirSync(dir).length) fs.rmdirSync(dir);
  }
}
function transaction(root, changes, previous, createdDirs) {
  let completed = 0;
  try {
    for (const item of changes) {
      const filename = safePath(root, item.name);
      if (item.bytes === null) { if (fs.existsSync(filename)) fs.unlinkSync(filename); }
      else atomicWrite(filename, item.bytes, item.mode ?? previous[completed].mode);
      completed++;
    }
  } catch (failure) {
    const rollbackErrors = [];
    for (let i = completed - 1; i >= 0; i--) {
      const item = previous[i];
      try {
        if (item.existed) atomicWrite(item.filename, item.bytes, item.mode);
        else if (fs.existsSync(item.filename)) fs.unlinkSync(item.filename);
      } catch (e) { rollbackErrors.push(item.name + ': ' + e.message); }
    }
    try { removeEmptyDirectories(root, createdDirs); } catch (e) { rollbackErrors.push(e.message); }
    error('Cài/phục hồi thất bại; đã hoàn tác các tệp ghi thành công. ' + failure.message + (rollbackErrors.length ? '\nKhông thể hoàn tác: ' + rollbackErrors.join('; ') : ''));
  }
}
function install({ target = DEFAULT_TARGET, packageRoot = __dirname, dryRun = false } = {}) {
  const root = targetRoot(target);
  const payload = payloadFiles(path.resolve(packageRoot));
  const changes = [...payload, ...patchEntries(root)];
  const planned = changes.map(item => ({ item, before: snapshot(root, item.name) })).filter(({ item, before }) => !before.existed || !before.bytes.equals(item.bytes));
  if (dryRun || !planned.length) return { target: root, dryRun, changed: planned.map(p => p.item.name), backupDir: null };
  const previous = planned.map(p => p.before), writing = planned.map(p => p.item);
  const createdDirs = missingDirectories(root, writing.map(item => item.name));
  const id = new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomBytes(3).toString('hex');
  const backupName = 'BACKUP/weapons-vfx/' + id;
  const backupDir = safePath(root, backupName);
  fs.mkdirSync(backupDir, { recursive: true });
  const manifest = {
    format: 'viet-village-weapons-vfx-backup-v2', target: root, createdAt: new Date().toISOString(), status: 'prepared',
    createdDirectories: createdDirs,
    entries: previous.map((before, index) => ({ path: before.name, existed: before.existed, mode: before.mode, originalSha256: before.existed ? sha(before.bytes) : null, installedSha256: sha(writing[index].bytes) }))
  };
  for (const before of previous) if (before.existed) atomicWrite(safePath(backupDir, 'files/' + before.name), before.bytes, before.mode);
  const manifestFile = path.join(backupDir, 'manifest.json');
  atomicWrite(manifestFile, Buffer.from(JSON.stringify(manifest, null, 2) + '\n'), 0o644);
  transaction(root, writing, previous, createdDirs);
  manifest.status = 'complete';
  try { atomicWrite(manifestFile, Buffer.from(JSON.stringify(manifest, null, 2) + '\n'), 0o644); }
  catch (failure) {
    transaction(root, previous.map(item => ({ name: item.name, bytes: item.bytes, mode: item.mode })), writing.map(item => snapshot(root, item.name)), []);
    removeEmptyDirectories(root, createdDirs);
    error('Không ghi được manifest hoàn tất; đã hoàn tác cài đặt. ' + failure.message);
  }
  return { target: root, dryRun: false, changed: writing.map(item => item.name), backupDir };
}
function restore({ target = DEFAULT_TARGET, backupDir, dryRun = false } = {}) {
  const root = targetRoot(target);
  if (!backupDir) error('Cần --restore đường-dẫn-thư-mục-backup.');
  const backup = fs.realpathSync(path.resolve(backupDir));
  const manifestFile = safePath(backup, 'manifest.json');
  const manifest = JSON.parse(readUtf8(manifestFile).text);
  if (manifest.format !== 'viet-village-weapons-vfx-backup-v2' || !Array.isArray(manifest.entries) || !Array.isArray(manifest.createdDirectories)) error('Manifest backup không hợp lệ.');
  if (normalize(manifest.target) !== normalize(root)) error('Backup thuộc thư mục đích khác; không phục hồi vào ' + root);
  if (!['complete', 'restored'].includes(manifest.status)) error('Backup chưa hoàn tất; không tự phục hồi từ manifest trạng thái ' + manifest.status);
  const names = new Set(), changes = [], previous = [];
  for (const entry of manifest.entries) {
    assertRelative(entry.path);
    if ((!allowedPayload(entry.path) && !ENTRY_FILES.includes(entry.path)) || names.has(entry.path)) error('Manifest chứa đường dẫn không được phép hoặc bị trùng: ' + entry.path);
    names.add(entry.path);
    const before = snapshot(root, entry.path);
    let bytes = null;
    if (entry.existed) {
      bytes = fs.readFileSync(safePath(backup, 'files/' + entry.path));
      if (sha(bytes) !== entry.originalSha256) error('Backup bị thay đổi/hỏng: ' + entry.path);
    }
    const alreadyOriginal = entry.existed ? before.existed && before.bytes.equals(bytes) : !before.existed;
    if (manifest.status === 'restored' && alreadyOriginal) continue;
    if (!before.existed || sha(before.bytes) !== entry.installedSha256) error('Tệp đã thay đổi sau lúc cài: ' + entry.path + '. Dừng phục hồi để giữ bản sửa mới.');
    changes.push({ name: entry.path, bytes, mode: entry.mode }); previous.push(before);
  }
  for (const name of manifest.createdDirectories) { assertRelative(name); safePath(root, name); }
  if (dryRun || !changes.length) return { target: root, dryRun, restored: changes.map(item => item.name), backupDir: backup };
  transaction(root, changes, previous, []);
  try {
    removeEmptyDirectories(root, manifest.createdDirectories);
    manifest.status = 'restored'; manifest.restoredAt = new Date().toISOString();
    atomicWrite(manifestFile, Buffer.from(JSON.stringify(manifest, null, 2) + '\n'), 0o644);
  } catch (failure) {
    transaction(root, previous.map(item => ({ name: item.name, bytes: item.bytes, mode: item.mode })), changes.map(item => snapshot(root, item.name)), []);
    error('Không hoàn tất phục hồi; đã trả lại bản đang cài. ' + failure.message);
  }
  return { target: root, dryRun: false, restored: changes.map(item => item.name), backupDir: backup };
}
function usage() {
  return 'Cài bộ VFX vào bản game thử nghiệm (cần Node.js).\n' +
    '  node INSTALL-WEAPONS-VFX.cjs [--target "thư-mục-game"] [--dry-run]\n' +
    '  node INSTALL-WEAPONS-VFX.cjs --target "thư-mục-game" --restore "thư-mục-backup" [--dry-run]\n' +
    'Đích mặc định: ' + DEFAULT_TARGET + '\nKhông chạy Git, không cập nhật nhánh main hoặc thư mục cha.';
}
function parseArgs(args) {
  const options = {};
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--dry-run') options.dryRun = true;
    else if (arg === '--help' || arg === '-h') options.help = true;
    else if (arg === '--target' || arg === '--restore') {
      if (!args[i + 1] || args[i + 1].startsWith('--')) error('Thiếu giá trị cho ' + arg);
      const key = arg === '--target' ? 'target' : 'backupDir';
      if (options[key]) error('Tham số bị trùng: ' + arg);
      options[key] = args[++i];
    } else if (!arg.startsWith('-') && !options.target) options.target = arg;
    else error('Tham số không được hỗ trợ: ' + arg);
  }
  return options;
}
if (require.main === module) {
  try {
    const options = parseArgs(process.argv.slice(2));
    if (options.help) console.log(usage());
    else {
      const result = options.backupDir ? restore(options) : install(options);
      console.log((result.dryRun ? 'KIỂM TRA, CHƯA GHI TỆP' : options.backupDir ? 'ĐÃ PHỤC HỒI' : result.changed.length ? 'ĐÃ CÀI VFX' : 'ĐÃ CÀI ĐÚNG, KHÔNG CẦN GHI LẠI') + '\nĐích: ' + result.target);
      for (const filename of result.changed || result.restored) console.log('  ' + filename);
      if (result.backupDir) console.log('Backup: ' + result.backupDir);
    }
  } catch (e) { console.error('DỪNG: ' + e.message); process.exitCode = 1; }
}
module.exports = { install, restore, parseArgs, DEFAULT_TARGET, SCRIPTS, REQUIRED, MARKERS };
