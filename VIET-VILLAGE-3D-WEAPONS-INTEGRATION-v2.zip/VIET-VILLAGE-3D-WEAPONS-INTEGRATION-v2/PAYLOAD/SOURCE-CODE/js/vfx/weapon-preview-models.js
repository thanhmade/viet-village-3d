/*
 * VIET VILLAGE 3D — procedural prototype weapon models.
 * These silhouettes follow the five supplied concept sheets; they are preview
 * meshes, not finished engraved, textured, or rigged GLB assets.
 *
 * WeaponPreviewModels.create(THREE, weaponId) returns { group, tip, dispose }.
 * The group's origin is the centre of the grip. Attach it to the actor's hand;
 * tip is an Object3D suitable for passing to WeaponVFXCore.cast().
 * This module owns no scene, renderer, DOM element, animation loop, or network.
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WeaponPreviewModels = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const WEAPON_IDS = Object.freeze(['staff', 'sword', 'spear', 'bow', 'axe']);

  function create(T, weaponId) {
    if (!T || typeof T.Group !== 'function' || typeof T.Mesh !== 'function') {
      throw new TypeError('WeaponPreviewModels.create requires the game THREE instance.');
    }
    if (!WEAPON_IDS.includes(weaponId)) {
      throw new RangeError('Unknown weaponId: ' + String(weaponId));
    }

    const group = new T.Group();
    group.name = 'weapon-preview-' + weaponId;
    group.userData.weaponId = weaponId;
    group.userData.prototype = true;
    const body = new T.Group();
    body.name = weaponId + '-geometry';
    group.add(body);
    const tip = new T.Object3D();
    tip.name = weaponId + '-tip';
    body.add(tip);
    const geometries = new Set();
    const materials = new Set();
    const palette = new Map();
    let disposed = false;

    function material(key) {
      if (palette.has(key)) return palette.get(key);
      const values = {
        gold: { color: 0xa38a50, metalness: 0.45, roughness: 0.4 },
        steel: { color: 0xb8c1bb, metalness: 0.82, roughness: 0.28 },
        edge: { color: 0xe1e6db, metalness: 0.7, roughness: 0.22 },
        wood: { color: 0x563b28, roughness: 0.86 },
        grip: { color: 0x292a21, roughness: 0.86 },
        tassel: { color: 0x7e2524, roughness: 0.86 }
      };
      const m = new T.MeshStandardMaterial(values[key]);
      m.name = 'weapon-preview-' + key;
      materials.add(m);
      palette.set(key, m);
      return m;
    }
    function mesh(geometry, m, parent = body) {
      geometries.add(geometry);
      const object = new T.Mesh(geometry, m);
      object.castShadow = true;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    }
    function box(w, h, d, m, x, y, z, parent = body) {
      const object = mesh(new T.BoxGeometry(w, h, d), m, parent);
      object.position.set(x, y, z);
      return object;
    }
    function cylinder(parent, radius, height, m, y = 0, rotation = 0) {
      const object = mesh(new T.CylinderGeometry(radius, radius, height, 12), m, parent);
      object.position.y = y;
      object.rotation.z = rotation;
      return object;
    }
    function shapeMesh(parent, points, m, depth = 0.05) {
      const shape = new T.Shape();
      points.forEach((p, i) => i ? shape.lineTo(p[0], p[1]) : shape.moveTo(p[0], p[1]));
      shape.closePath();
      const geometry = new T.ExtrudeGeometry(shape, {
        depth, bevelEnabled: true, bevelThickness: 0.007,
        bevelSize: 0.008, bevelSegments: 1, steps: 1
      });
      const object = mesh(geometry, m, parent);
      object.position.z = -depth / 2;
      return object;
    }
    function tube(parent, points, radius, m) {
      const curve = new T.CatmullRomCurve3(points.map(p => new T.Vector3(...p)));
      return mesh(new T.TubeGeometry(curve, 28, radius, 6, false), m, parent);
    }
    function ring(parent, y, radius = 0.055, m = material('gold')) {
      const object = mesh(new T.TorusGeometry(radius, 0.013, 5, 16), m, parent);
      object.rotation.x = Math.PI / 2;
      object.position.y = y;
      return object;
    }

    const gold = material('gold');
    const wood = material('wood');
    const grip = material('grip');

    if (weaponId === 'staff') {
      body.scale.setScalar(0.9);
      cylinder(body, 0.055, 2.8, wood, 0, Math.PI / 2);
      for (const x of [-1.3, -1.16, -0.3, 0.3, 1.16, 1.3]) {
        const radius = Math.abs(x) > 1 ? 0.072 : 0.063;
        const cap = cylinder(body, radius, 0.12, gold, 0, Math.PI / 2);
        cap.position.x = x;
        const rim = ring(body, 0, radius + 0.002);
        rim.rotation.set(0, Math.PI / 2, 0);
        rim.position.x = x;
      }
      cylinder(body, 0.063, 0.5, grip, 0, Math.PI / 2);
      for (let i = 0; i < 12; i++) {
        const wrap = ring(body, 0, 0.064, grip);
        wrap.rotation.set(0, Math.PI / 2, 0);
        wrap.position.x = -0.22 + i * 0.04;
      }
      for (const side of [-1, 1]) {
        tube(body, [[side * 0.42, 0.053, 0.025], [side * 0.65, 0.015, 0.054],
          [side * 0.83, -0.043, 0.03], [side * 1.05, 0.035, 0.04]], 0.008, gold);
      }
      tip.position.x = 1.4;
    } else if (weaponId === 'sword') {
      body.position.y = 0.12;
      const steel = material('steel'), edge = material('edge');
      cylinder(body, 0.056, 0.37, grip, -0.12);
      for (let i = 0; i < 8; i++) ring(body, -0.28 + i * 0.045, 0.056, grip);
      cylinder(body, 0.072, 0.07, gold, -0.32);
      const pommel = mesh(new T.SphereGeometry(0.095, 12, 8), gold);
      pommel.position.y = -0.39;
      pommel.scale.z = 0.52;
      shapeMesh(body, [[-0.31, 0.03], [-0.3, 0.13], [-0.15, 0.17], [0, 0.23],
        [0.15, 0.17], [0.3, 0.13], [0.31, 0.03], [0.13, 0.055], [0, -0.01], [-0.13, 0.055]], gold, 0.085);
      shapeMesh(body, [[-0.095, 0.16], [-0.09, 1.35], [0, 1.62], [0.09, 1.35], [0.095, 0.16]], steel, 0.045);
      shapeMesh(body, [[-0.012, 0.18], [-0.01, 1.32], [0, 1.61], [0.012, 1.32], [0.012, 0.18]], edge, 0.066);
      const emblem = mesh(new T.TorusGeometry(0.055, 0.012, 5, 12), gold);
      emblem.position.set(0, 0.1, -0.055);
      tip.position.y = 1.62;
    } else if (weaponId === 'spear') {
      // Shift the lower wrapped grip to the hand origin and scale total length.
      body.scale.setScalar(0.82);
      body.position.y = 0.65 * 0.82;
      const steel = material('steel'), edge = material('edge'), tassel = material('tassel');
      cylinder(body, 0.04, 2.75, wood, 0.1);
      cylinder(body, 0.047, 0.56, grip, -0.65);
      for (const y of [-1.22, -0.92, -0.4, 0.38, 1.24, 1.43]) {
        cylinder(body, 0.055, 0.1, gold, y);
        ring(body, y, 0.057);
      }
      shapeMesh(body, [[0, 2.04], [-0.14, 1.58], [-0.09, 1.41], [0, 1.47],
        [0.09, 1.41], [0.14, 1.58]], steel, 0.065);
      shapeMesh(body, [[0, 2.04], [-0.018, 1.52], [0, 1.46], [0.018, 1.52]], edge, 0.075);
      const threads = new T.Group();
      threads.name = 'spear-tassel';
      threads.position.y = 1.35;
      body.add(threads);
      for (let i = 0; i < 15; i++) {
        const angle = i / 15 * Math.PI * 2;
        const dx = Math.sin(angle) * 0.09, dz = Math.cos(angle) * 0.09;
        // Fixed variation avoids Math.random(): the same spear always recreates.
        const lengthVariation = ((i * 7 + 3) % 15) / 15 * 0.1;
        tube(threads, [[dx, 0, dz], [dx * 1.8, -0.24, dz * 1.7],
          [dx * 2, -0.47 + lengthVariation, dz * 1.5]], 0.007, tassel);
      }
      const charm = mesh(new T.TorusGeometry(0.045, 0.011, 5, 12), gold);
      charm.position.set(0.1, 1.06, -0.1);
      tip.position.y = 2.04;
    } else if (weaponId === 'bow') {
      body.position.z = 0.26;
      const steel = material('steel');
      const limb = [[0, -1.07, 0.14], [0, -0.87, -0.08], [0, -0.55, -0.38],
        [0, -0.25, -0.31], [0, 0, -0.26], [0, 0.25, -0.31],
        [0, 0.55, -0.38], [0, 0.87, -0.08], [0, 1.07, 0.14]];
      tube(body, limb, 0.043, wood);
      cylinder(body, 0.054, 0.32, grip).position.z = -0.26;
      for (const y of [-0.95, -0.4, 0.4, 0.95]) {
        const point = limb.reduce((best, p) => Math.abs(p[1] - y) < Math.abs(best[1] - y) ? p : best, limb[0]);
        const trim = mesh(new T.SphereGeometry(0.057, 8, 6), gold);
        trim.position.set(0, y, point[2]);
        trim.scale.set(0.8, 1.6, 0.9);
      }
      const stringGeometry = new T.BufferGeometry();
      stringGeometry.setAttribute('position', new T.Float32BufferAttribute([
        0, 1.07, 0.14, 0, 0, 0.14, 0, -1.07, 0.14
      ], 3));
      geometries.add(stringGeometry);
      const stringMaterial = new T.LineBasicMaterial({ color: 0xb8a67b });
      materials.add(stringMaterial);
      const string = new T.Line(stringGeometry, stringMaterial);
      string.name = 'bow-string';
      body.add(string);
      const arrow = new T.Group();
      arrow.name = 'bow-arrow';
      arrow.position.y = 0.035;
      body.add(arrow);
      const shaft = cylinder(arrow, 0.012, 1.6, wood);
      shaft.rotation.x = Math.PI / 2;
      const point = mesh(new T.ConeGeometry(0.044, 0.17, 4), steel, arrow);
      point.rotation.x = -Math.PI / 2;
      point.position.z = -0.85;
      for (const x of [-0.035, 0.035]) box(0.018, 0.12, 0.16, gold, x, 0, 0.62, arrow);
      tip.position.set(0, 0.035, -0.93);
    } else if (weaponId === 'axe') {
      body.position.y = 0.6;
      const steel = material('steel'), edge = material('edge');
      cylinder(body, 0.052, 1.88, wood, -0.06);
      cylinder(body, 0.058, 0.57, grip, -0.6);
      for (const y of [-0.93, -0.32, 0.13, 0.77, 0.98]) {
        cylinder(body, 0.068, 0.11, gold, y);
        ring(body, y, 0.071);
      }
      // One broad blade and an opposing short spike, as in the reference.
      shapeMesh(body, [[-0.07, 1.05], [-0.31, 1.11], [-0.62, 1.4], [-0.78, 1.17],
        [-0.85, 0.83], [-0.8, 0.47], [-0.66, 0.24], [-0.47, 0.65], [-0.26, 0.73], [-0.06, 0.68]], steel, 0.09);
      shapeMesh(body, [[-0.63, 1.4], [-0.79, 1.18], [-0.86, 0.83], [-0.81, 0.47],
        [-0.66, 0.24], [-0.61, 0.43], [-0.71, 0.78], [-0.67, 1.12]], edge, 0.095);
      shapeMesh(body, [[0.02, 1.03], [0.19, 1.04], [0.33, 0.94], [0.13, 0.92], [0.03, 0.78]], steel, 0.08);
      const disk = mesh(new T.CylinderGeometry(0.13, 0.13, 0.03, 16), gold);
      disk.rotation.x = Math.PI / 2;
      disk.position.set(-0.42, 0.85, -0.066);
      const pommel = mesh(new T.TorusGeometry(0.075, 0.021, 6, 12), gold);
      pommel.position.y = -1.09;
      tip.position.set(-0.65, 1.3, 0);
    }

    group.updateMatrixWorld(true);
    function dispose() {
      if (disposed) return;
      disposed = true;
      group.userData.disposed = true;
      group.removeFromParent();
      geometries.forEach(geometry => geometry.dispose());
      materials.forEach(m => m.dispose());
      geometries.clear();
      materials.clear();
      palette.clear();
    }
    return { group, tip, dispose };
  }

  return Object.freeze({ weaponIds: WEAPON_IDS, create });
});
