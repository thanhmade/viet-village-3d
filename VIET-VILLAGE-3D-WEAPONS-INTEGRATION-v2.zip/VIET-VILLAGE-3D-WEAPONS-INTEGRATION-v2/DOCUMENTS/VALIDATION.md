# Kiểm tra gói kết nối — 2026-10-11

## Kết quả

| Lớp kiểm tra | Kết quả |
|---|---|
| Core 15 chiêu | 16/16 test đạt, Three.js thật |
| Installer | 15/15 test đạt |
| Adapter nối game | 11/11 test đạt |
| Tổng suite đi kèm | **42/42 đạt** |
| Đọc khai báo lexical thật của bản nền | 11/11 test adapter đạt |
| Cài lên bản sao nguồn nền rồi chạy mọi script trong HTML | Đạt, thi triển đủ 15 chiêu trong tick thật của game |

Installer được kiểm tra với HTML và split scripts nền nguyên văn: thứ tự nạp và hook một lần, dry-run không ghi, cài lại không đổi, thiếu payload/cấu trúc lạ không ghi, đúng tay/đất/va chạm, backup, restore byte/BOM/CRLF, lỗi ghi và rollback. Root index, README, Firebase giả lập trong fixture giữ nguyên. Restore từ chối backup sai đích, hỏng hoặc file đã được sửa sau cài.

Adapter dùng Three.js thật và DOM/render mô phỏng để kiểm tra nhận scene/player/body lexical, deferred attach khi tải trước app, hướng chiêu, đủ 5 vũ khí/15 chiêu, di chuyển và cao độ, cooldown, chặn form/overlay/nội thất, sự kiện và dọn tài nguyên. Kiểm tra đã phát hiện lỗi thoát luyện chiêu ghi đè góc Camera/Nhà dân vừa chọn; listener capture đã sửa và hồi quy đạt.

## Kiểm tra trên toàn bộ code nền

Đã sao chép các script nguồn nền hiện có sang thư mục tạm, cài bằng chính installer, đọc thứ tự script từ `SOURCE-CODE/index.html` đã vá và thực thi tất cả script game. Đã chạy `tick(ms)` thật 1.526 lượt render giả lập, di chuyển theo `canWalk` thật, chọn cả 5 vũ khí và cast đủ 15 chiêu; sự kiện cast ghi nhận đủ 15. Scene, renderer và camera giữ nguyên đối tượng. Adapter không tạo RAF mới; lần khởi tạo có đúng một lời gọi RAF của game.

Kết quả này cho thấy điểm nối hoạt động với **bản nguồn nền đã có trong phiên**. Nó không chứng minh ổ H: của thầy đã được sửa hoặc bản Firebase mới trên máy có cùng cấu trúc. Installer kiểm tra cấu trúc tại máy đích trước khi vá.

Renderer, DOM, input và canvas trong các kiểm tra là mô phỏng. Chưa chạy trình duyệt/GPU thật cho trang game đã nối. Phần shader của core giữ nguyên từ gói VFX v2 đã được kiểm tra EGL trước đó; gói nối mới cần mở trên máy thầy để đánh giá hình ảnh và thao tác thực tế.

## Chạy lại suite

Từ thư mục gói:

```bash
node --test tests/*.test.cjs
```

Hoặc trên Command Prompt nếu cần truyền tên file tường minh:

```bat
node --test tests/core.test.cjs tests/installer.test.cjs tests/integration.test.cjs
```

Three.js dùng cho test nằm riêng trong `TEST-ASSETS`; installer không chép engine này vào game. Game dùng Three.js đã có.

Báo cáo: `node-tests.tap`, `baseline-binding-tests.tap`, `full-game-vm-results.json` và `validation-results.json`. `SHA256SUMS.txt` kiểm tra các file trong gói, trừ chính danh sách hash.
